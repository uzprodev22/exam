<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="schedule-header">
    <span class="schedule-head-title"> <?php echo esc_html( $head_title ) ?> </span>
    <span class="schedule-head-date"><?php echo esc_html( $head_date ) ?></span>
</div>
